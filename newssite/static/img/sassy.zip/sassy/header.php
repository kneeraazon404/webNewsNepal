<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Faded_Small
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>
<?php 
    $opt = get_option('sassy_opt');
    $logo_main = isset($opt['logo-main']['url']) ? $opt['logo-main']['url'] : 'http://droitthemes.com/wp/sassy/wp-content/uploads/2019/01/sassy_white.png';
    $logo_sticky = isset($opt['logo-sticky']['url']) ? $opt['logo-sticky']['url'] : 'http://droitthemes.com/wp/sassy/wp-content/uploads/2019/01/sassy_black.png';
    $menu_btn_label = isset($opt['menu_btn_label']) ? $opt['menu_btn_label'] : 'Get Started';
    $menu_btn_url = isset($opt['menu_btn_url']) ? $opt['menu_btn_url'] : 'www.droitthemes.com';
?>
<body <?php body_class(); ?> data-spy="scroll" data-target=".navbar" data-offset="50" id="home">
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'sassy' ); ?></a>
		<nav class="navbar navbar-fixed-top new_header">
            <div class="container">
                <div class="row br">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand ex" href="http://droitthemes.com/wp/sassy/">                            
                             <img class="main-logo" src="<?php echo esc_url($logo_main); ?>" alt="Home">                               
                            <img class="logo-blue" src="<?php echo esc_url($logo_sticky); ?>" alt="Home">                                 
                        </a>
                        
                        <!--Get-Now-Button-->
                        <a class="btn-getnow new_btn" href="<?php echo esc_url($menu_btn_url); ?>"><?php echo esc_html($menu_btn_label); ?></a>
                    </div>
                    <div class="collapse navbar-collapse multi_page_menu_item" id="myNavbar">
                    	<?php
							
							if(has_nav_menu('primary_menu')) {
								wp_nav_menu( array(
									'theme_location' => 'primary_menu',
									'container' => null,
			                        'menu_class' => 'nav navbar-nav navbar-right multi',
			                       
									));
							}
						?>
                               
                    </div>
                </div>
            </div>
        </nav>
<div id="content" class="site-content">
