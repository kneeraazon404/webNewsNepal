<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Faded_Small
 */
$opt = get_option('faded-small_opt');
$footer = isset($opt['footer']) ? $opt['footer'] : '© 2018 DroitThemes. All rights reserved';
?>

</div><!-- #content -->

<footer class="saas_footer_area">
    <div class="container">
        <div class="row">
             <?php dynamic_sidebar('footer_widgets_1') ?>
             <?php dynamic_sidebar('footer_widgets_2') ?>
             <?php dynamic_sidebar('footer_widgets_3') ?>
             <?php dynamic_sidebar('footer_widgets_4') ?>
        </div>
        <div class="border_top"></div>
        <p class="copyright_text"> Designed &amp; Developed by <a href="https://droitthemes.com/" target="_blank"> DroitThemes </a></p>
    </div>
</footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
