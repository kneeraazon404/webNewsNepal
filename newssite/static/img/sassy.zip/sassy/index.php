<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Faded_Small
 */

get_header();
?>
    <section class="n_blog_area">
            <div class="container">
                <div class="row d_flex">
                	<?php 	while(have_posts()): the_post(); ?>
	                    <div class="col-md-4">
	                        <div class="n_blog-item">
	                            <?php the_post_thumbnail(); ?>
	                            <div class="n_post_date"><?php the_date('M d') ?></div>
	                            <div class="n_blog_content text-left">
	                                <a href="#"><h2 class="n_title_color"><?php the_title() ?></h2></a>
	                               <?php the_content('<p class="p_color">','</p>'); ?>
	                                <a href="blog-detail.html"><?php echo __('Read more','sassy')?> <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
	                            </div>
	                        </div>
	                    </div>
                	<?php 	endwhile; ?>
                 
                </div>
            </div>
        </section>
<?php

get_footer();
