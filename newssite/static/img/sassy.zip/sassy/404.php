<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Faded_Small
 */

get_header();
?>
    <section class="error_page_area">
        <div class="container">
            <div class="error_content">
                <h1> <?php esc_html_e('404', 'sassy'); ?> </h1>
                <h2> <?php esc_html_e('Oops, This Page Could Not Be Found!', 'sassy'); ?> </h2>
                <p> <?php esc_html_e('The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.', 'sassy'); ?> </p>
               
            </div>
        </div>
    </section>

<?php
get_footer();
