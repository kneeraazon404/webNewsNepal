<?php

// Register Widget areas
add_action('widgets_init', function() {

 
 
    register_sidebar(array(
        'name'          => esc_html__('Footer widgets 1', 'sassy'),
        'description'   => esc_html__('Add widgets here for footer left widgets area', 'sassy'),
        'id'            => 'footer_widgets_1',
        'before_widget' => '<div class="col-md-5"><div id="%1$s" class="f_widget about_widget %2$s">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h3 class="widget_title">',
        'after_title'   => '</h3>'
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer widgets 2', 'sassy'),
        'description'   => esc_html__('Add widgets here for footer left middle widgets area', 'sassy'),
        'id'            => 'footer_widgets_2',
        'before_widget' => '<div class="col-md-2"><div id="%1$s" class="f_widget link_widget %2$s">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h3 class="widget_title">',
        'after_title'   => '</h3>'
    ));


    register_sidebar(array(
        'name'          => esc_html__('Footer widgets 3', 'sassy'),
        'description'   => esc_html__('Add widgets here for footer right middle widgets area', 'sassy'),
        'id'            => 'footer_widgets_3',
        'before_widget' => '<div class="col-md-2"><div id="%1$s" class="f_widget link_widget %2$s">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h3 class="widget_title">',
        'after_title'   => '</h3>'
    ));


    register_sidebar(array(
        'name'          => esc_html__('Footer widgets 4', 'sassy'),
        'description'   => esc_html__('Add widgets here for footer right widgets area', 'sassy'),
        'id'            => 'footer_widgets_4',
        'before_widget' => '<div class="col-md-3"><div id="%1$s" class="f_widget link_widget %2$s">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h3 class="widget_title">',
        'after_title'   => '</h3>'
    ));


});


