<?php

/**
 * Created by Mainuddin Rashed.
 * User: DroitLab
 * Date: 25/11/2018
 * Time: 11:30 AM
 */
class About_Us_Widgets extends WP_Widget {

    public function __construct() {
        parent::__construct(
                'about_us_widgets', esc_html__('Small Themes :: About Us Widget', 'sassy'), array('description' => esc_html__('Display logo, short description along with social accounts.', 'sassy'))
        );
    }

    public function form($instance) {
        ?>
        <p>
          <label for="<?php echo esc_attr($this->get_field_id('faded-small_sl_logo_hdn_input')); ?>"><?php echo esc_html__('Put Image URL below (Go to media ang get link from there):', 'sassy'); ?></label><br />
            <!--  -->
                <input id="faded-small_sl_logo_hdn_input" class="input_image_value" type="text" name="<?php echo esc_attr($this->get_field_name('image_uri')); ?>" value="<?php
            if (!empty($instance['image_uri'])) {
                echo esc_url($instance['image_uri']);
            }
            ?>">
                <span id="img-span"></span>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('company_description')); ?>"><?php echo esc_html__('Description', 'sassy'); ?></label><br />
            <textarea class="widefat" rows="10" name="<?php echo esc_attr($this->get_field_name('company_description')); ?>" id="<?php echo esc_attr($this->get_field_id('company_description')); ?>"><?php if (!empty($instance['company_description'])) echo esc_html($instance['company_description']); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_fb')); ?>"><?php echo esc_html__('Facebook Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_fb')); ?>" id="<?php echo esc_attr($this->get_field_id('social_fb')); ?>" value="<?php if (!empty($instance['social_fb'])) echo esc_html($instance['social_fb']); ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_twitter')); ?>"><?php echo esc_html__('Twitter Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_twitter')); ?>" id="<?php echo esc_attr($this->get_field_id('social_twitter')); ?>" value="<?php if (!empty($instance['social_twitter'])) echo esc_html($instance['social_twitter']); ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_instagram')); ?>"><?php echo esc_html__('Instagram Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_instagram')); ?>" id="<?php echo esc_attr($this->get_field_id('social_instagram')); ?>" value="<?php
            if (!empty($instance['social_instagram'])) {
                echo esc_attr($instance['social_instagram']);
            }
            ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_linkedin')); ?>"><?php echo esc_html__('Linkedin Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_linkedin')); ?>" id="<?php echo esc_attr($this->get_field_id('social_linkedin')); ?>" value="<?php
            if (!empty($instance['social_linkedin'])) {
                echo esc_attr($instance['social_linkedin']);
            }
            ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_gplus')); ?>"><?php echo esc_html__('Google Plus Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_gplus')); ?>" id="<?php echo esc_attr($this->get_field_id('social_gplus')); ?>" value="<?php
            if (!empty($instance['social_gplus'])) {
                echo esc_attr($instance['social_gplus']);
            }
            ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_pinterest')); ?>"><?php echo esc_html__('Pinterest Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_pinterest')); ?>" id="<?php echo esc_attr($this->get_field_id('social_pinterest')); ?>" value="<?php
            if (!empty($instance['social_pinterest'])) {
                echo esc_attr($instance['social_pinterest']);
            }
            ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_behance')); ?>"><?php echo esc_html__('Behance Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_behance')); ?>" id="<?php echo esc_attr($this->get_field_id('social_behance')); ?>" value="<?php
            if (!empty($instance['social_behance'])) {
                echo esc_attr($instance['social_behance']);
            }
            ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_dribble')); ?>"><?php echo esc_html__('Dribble Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_dribble')); ?>" id="<?php echo esc_attr($this->get_field_id('social_dribble')); ?>" value="<?php
            if (!empty($instance['social_dribble'])) {
                echo esc_attr($instance['social_dribble']);
            }
            ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('social_git')); ?>"><?php echo esc_html__('Github Profile', 'sassy'); ?></label><br />
            <input class="widefat" name="<?php echo esc_attr($this->get_field_name('social_git')); ?>" id="<?php echo esc_attr($this->get_field_id('social_git')); ?>" value="<?php
            if (!empty($instance['social_git'])) {
                echo esc_attr($instance['social_git']);
            }
            ?>"/>
        </p>
        <?php
    }

    public function widget($args, $instance) {

        echo wp_kses_post($args['before_widget']); 
        ?>

            <div class="footer_left footer_top_single">
                <?php
                if (!empty($instance['image_uri'])) {
                    ?>
                  
                    <a  class="f_logo" href="<?php echo esc_url(site_url()); ?>">
                        <img src="<?php echo esc_url($instance['image_uri']); ?>" alt="<?php echo esc_html__('f-logo','sassy') ?>">
                    </a>
                    
                    <?php
                }
                ?>
                <p><?php
                    if (!empty($instance['company_description'])) {
                        echo esc_html($instance['company_description']);
                    }
                    ?>
                        
                </p>
               
                <ul class="f_social_icon">
                   
                    <?php
                    if (!empty($instance['social_fb'])) {
                        ?><li><a target="_blank" href="<?php echo esc_url($instance['social_fb']); ?>"><i class="fa fa-facebook"></i></a></li><?php
                    }
                    if (!empty($instance['social_twitter'])) {
                        ?><li><a target="_blank" href="<?php echo esc_url($instance['social_twitter']); ?>"><i class="fa fa-twitter"></i></a></li><?php
                            }
                            if (!empty($instance['social_instagram'])) {
                                ?><li><a target="_blank" href="<?php echo esc_url($instance['social_instagram']); ?>"><i class="fa fa-instagram"></i></a></li><?php
                            }
                            if (!empty($instance['social_linkedin'])) {
                                ?><li><a target="_blank" href="<?php echo esc_url($instance['social_linkedin']); ?>"><i class="fa fa-linkedin"></i></a></li><?php
                            }
                            if (!empty($instance['social_gplus'])) {
                                ?><li><a target="_blank" href="<?php echo esc_url($instance['social_gplus']); ?>"><i class="fa fa-google-plus"></i></a></li><?php
                            }
                            if (!empty($instance['social_pinterest'])) {
                                ?><li><a target="_blank" href="<?php echo esc_url($instance['social_pinterest']); ?>"><i class="social_pinterest"></i></a></li><?php
                            }
                            if (!empty($instance['social_behance'])) {
                                ?><li><a target="_blank" href="<?php echo esc_url($instance['social_behance']); ?>"><i class="fa fa-behance"></i></a></li><?php
                            }
                            if (!empty($instance['social_dribble'])) {
                                ?><li><a target="_blank" href="<?php echo esc_url($instance['social_dribble']); ?>"><i class="social_dribble"></a></li><?php
                            }
                            if (!empty($instance['social_git'])) {
                                ?><li><a target="_blank" href="<?php echo esc_url($instance['social_git']); ?>"><i class="social_dribble"></i></a></li><?php
                            }
                            ?>
                </ul>
                
            </div>

        
        <?php
         echo wp_kses_post($args['after_widget']); 
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['image_uri'] = strip_tags($new_instance['image_uri']);
        $instance['company_description'] = strip_tags($new_instance['company_description']);
        $instance['social_fb'] = strip_tags($new_instance['social_fb']);
        $instance['social_twitter'] = strip_tags($new_instance['social_twitter']);
        $instance['social_instagram'] = strip_tags($new_instance['social_instagram']);
        $instance['social_linkedin'] = strip_tags($new_instance['social_linkedin']);
        $instance['social_gplus'] = strip_tags($new_instance['social_gplus']);
        $instance['social_pinterest'] = strip_tags($new_instance['social_pinterest']);
        $instance['social_behance'] = strip_tags($new_instance['social_behance']);
        $instance['social_dribble'] = strip_tags($new_instance['social_dribble']);
        $instance['social_git'] = strip_tags($new_instance['social_git']);
        return $instance;
    }

}

// register faded-small_Logo_Social_Widget
function about_us_widgets() {
    register_widget('About_Us_widgets');
}

add_action('widgets_init', 'about_us_widgets');

