<?php
/**
 * Created by Mainuddin Rashed.
 * User: DroitLab
 * Date: 17/0/2018
 * Time: 12:30 AM
 */

class Footer_Links_Widgets extends WP_Widget {

        public function __construct() {
            $widget_ops = array( 'footer_links_widgets' => __('Add a custom menu to your footer sidebar.','sassy') );
             parent::__construct( 'nav_menu', __('Droit Themes Links :: Footer Menus','sassy'), $widget_ops );
        }

        function widget($args, $instance) {
        	echo wp_kses_post($args['before_widget']);
            ?> 
             <?php
            // Get menu
            $nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

            if ( !$nav_menu )
                return;
           
            /** This filter is documented in wp-includes/default-widgets.php */

            $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );


            if ( !empty($instance['title']) )
                
            echo wp_kses($args['before_title'] . $instance['title'] . $args['after_title'],wp_kses_allowed_html('post'));
           
            wp_nav_menu( array( 'fallback_cb' => '', 'menu' => $nav_menu, 'container_class' => '', 'menu_class' => '', ) );

            echo  wp_kses_post($args['after_widget']);
        }

        function update( $new_instance, $old_instance ) {
            $instance['title'] = strip_tags( stripslashes($new_instance['title']) );
            $instance['nav_menu'] = (int) $new_instance['nav_menu'];
            return $instance;
        }

        function form( $instance ) {
            $title = isset( $instance['title'] ) ? $instance['title'] : '';
            $nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

            // Get menus
            $menus = wp_get_nav_menus( array( 'orderby' => 'name' ) );

            // If no menus exists, direct the user to go and create some.
            if ( !$menus ) {
                echo '<p>'. sprintf( __('No menus have been created yet. <a href="%s">Create some</a>.','sassy'), admin_url('nav-menus.php') ) .'</p>';
                return;
            }
            ?>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:','sassy') ?></label>
                <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($title); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('nav_menu')); ?>"><?php esc_html_e('Select Menu:','sassy'); ?></label>

                <select id="<?php echo esc_attr($this->get_field_id('nav_menu')); ?>" name="<?php echo esc_attr($this->get_field_name('nav_menu')); ?>">
                    <option value="0"><?php esc_html_e( '&mdash; Select &mdash;' ,'sassy' ) ?></option>
            <?php
                foreach ( $menus as $menu ) {
                    echo '<option value="' . $menu->term_id . '"'
                        . selected( $nav_menu, $menu->term_id, false )
                        . '>'. esc_html( $menu->name ) . '</option>';
                }
            ?>
                </select>
            </p>
            <?php
        }
    }

// register faded-small_Logo_Social_Widget
function footer_links_widgets() {
    register_widget('Footer_Links_Widgets');
}

add_action('widgets_init', 'footer_links_widgets');

