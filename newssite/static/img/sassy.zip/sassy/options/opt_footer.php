<?php
// Footer Section
Redux::setSection('sassy_opt', array(
	'title'     => esc_html__('Footer Settings', 'sassy'),
	'id'        => 'opt_footer',
	'icon'      => 'dashicons dashicons-download',
	'fields'    => array(
		array(
			'title'     => esc_html__('Copyright text', 'sassy'),
			'subtitle'  => esc_html__('Footer Copyright text', 'sassy'),
			'id'        => 'footer',
			'type'      => 'editor',
			'default'   => '© 2018 <a href="http://droitthemes.com">DroitThemes</a>. All rights reserved',
			'args'    => array(
				'wpautop'       => true,
				'media_buttons' => false,
				'textarea_rows' => 5,
				'teeny'         => false,
				'quicktags'     => false,
			)
		),
	)
));

