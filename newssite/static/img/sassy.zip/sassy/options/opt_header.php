<?php

// Header Section
Redux::setSection('sassy_opt', array(
	'title'            => esc_html__( 'Header Settings', 'sassy' ),
	'id'               => 'header_sec',
	'customizer_width' => '400px',
	'icon'             => 'el el-home'
) );


Redux::setSection('sassy_opt', array(
	'title'            => esc_html__( 'Logo', 'sassy' ),
	'id'               => 'logo_opt',
	'subsection'       => true,
	'icon'             => 'dashicons dashicons-schedule',
	'fields'           => array(
		array(
			'title'     => esc_html__('Logo Main', 'appi'),
			'subtitle'  => esc_html__( 'Upload here a image file for your logo', 'appi' ),
			'id'        => 'logo-main',
			'type'      => 'media',
			'compiler'  => true,
			'default'  => array(
				'url'   => 'http://droitthemes.com/wp/sassy/wp-content/uploads/2019/01/sassy_white.png',
			)
		),
		array(
			'title'     => esc_html__('Logo Srticky', 'appi'),
			'subtitle'  => esc_html__( 'Upload here a image file for your logo', 'appi' ),
			'id'        => 'logo-sticky',
			'type'      => 'media',
			'compiler'  => true,
			'default'  => array(
				'url'   => 'http://droitthemes.com/wp/sassy/wp-content/uploads/2019/01/sassy_black.png',
			)
		),
		
	)
) );


// Menu action button
Redux::setSection('sassy_opt', array(
	'title'            => esc_html__( 'Menu Action Button', 'sassy' ),
	'id'               => 'menu_action_btn_opt',
	'subsection'       => true,
	'icon'             => 'dashicons dashicons-minus',
	'fields'           => array(
		array(
			'title'     => esc_html__('Button label', 'sassy'),
			'subtitle'  => esc_html__('Leave the button label field empty to hide the menu action button.', 'sassy'),
			'id'        => 'menu_btn_label',
			'type'      => 'text',
			'default'   => 'Get Started'
		),
		array(
			'title'     => esc_html__('Button URL', 'sassy'),
			'id'        => 'menu_btn_url',
			'type'      => 'text',
			'default'   => '#'
		),
		
	)
));

