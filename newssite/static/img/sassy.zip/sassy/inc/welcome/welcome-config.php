<?php
	/**
	 * Welcome Page Initiation
	*/

	include get_template_directory() . '/inc/welcome/welcome.php';

	/** Plugins **/
	$plugins = array(
		// *** Companion Plugins
		'companion_plugins' => array(),

		// *** Required Plugins
		'required_plugins' => array(

		),

		// *** Recommended Plugins
		'recommended_plugins' => array(

		),
	);

	$strings = array(
		// Welcome Page General Texts
		'welcome_menu_text' => esc_html__( 'Sassy Setup', 'sassy' ),
		'theme_short_description' => esc_html__( 'Sassy is a Creative App Landing WordPress Theme. It is 100% responsive and looks stunning on all types of screens and devices. You can use Appart as a better way to present and promote your start-up mobile apps, saas applications, software, digital products. Users will love your site because it gives them a unique user experience (UX), clean, modern & beautiful design', 'sassy' ),

		// Plugin Action Texts
		'install_n_activate' => esc_html__('Install and Activate', 'sassy'),
		'deactivate' => esc_html__('Deactivate', 'sassy'),
		'activate' => esc_html__('Activate', 'sassy'),

		// Getting Started Section
		'doc_heading' => esc_html__('Step 1 - Documentation', 'sassy'),
		'doc_description' => esc_html__('Read the Documentation and follow the instructions to manage the site , it helps you to set up the theme more easily and quickly. The Documentation is very easy with its pictorial  and well managed listed instructions. ', 'sassy'),
		'doc_read_now' => esc_html__( 'Read Now', 'sassy' ),
		'cus_heading' => esc_html__('Step 2 - Redux Theme Options', 'sassy'),
		'cus_description' => esc_html__('Using the Theme Settings you can easily customize every aspect of the theme globally.', 'sassy'),
		'cus_read_now' => esc_html__( 'Go to Theme Settings', 'sassy' ),

		// Recommended Plugins Section
		'pro_plugin_title' => esc_html__( 'Pro Plugins', 'sassy' ),
		'pro_plugin_description' => esc_html__( 'Take Advantage of some of our Premium Plugins.', 'sassy' ),
		'free_plugin_title' => esc_html__( 'Free Plugins', 'sassy' ),
		'free_plugin_description' => esc_html__( 'These Free Plugins might be handy for you.', 'sassy' ),

		// Demo Actions
		'activate_btn' => esc_html__('Activate', 'sassy'),
		'installed_btn' => esc_html__('Activated', 'sassy'),
		'demo_installing' => esc_html__('Installing Demo', 'sassy'),
		'demo_installed' => esc_html__('Demo Installed', 'sassy'),
		'demo_confirm' => esc_html__('Are you sure to import demo content ?', 'sassy'),

		// Actions Required
		'req_plugins_installed' => esc_html__( 'All Recommended action has been successfully completed.', 'sassy' ),
		'customize_theme_btn' => esc_html__( 'Customize Theme', 'sassy' ),
	);

	/**
	 * Initiating Welcome Page
	*/
	$my_theme_wc_page = new constructera_Welcome( $plugins, $strings );
	