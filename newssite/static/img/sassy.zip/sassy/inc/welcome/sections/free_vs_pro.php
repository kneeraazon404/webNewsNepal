<div class="lightProTable">
    <div class="table-responsive">
        <table class="table">
            <tbody>
            <tr>
                <th><?php echo __('Theme Features','sassy'); ?></th>
                <th><?php echo __('Lite Version','sassy'); ?></th>
                <th><?php echo __('Pro Version','sassy'); ?></th>
            </tr>


            <tr>
                <th><?php echo __('All Features','sassy'); ?></th>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
            <tr>
                <th><?php echo __('Multipage','sassy'); ?></th>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
            <tr>
                <th><?php echo __('RTL','sassy'); ?></th>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
            <tr>
                <th><?php echo __('WPML','sassy'); ?></th>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>


            </tbody>
        </table>
    </div>
</div>

<div class="buyBtn text-center">
    <a href="https://themeforest.net/item/appart-creative-app-landing-wordpress-theme/21915180?s_rank=4" class="btn btnBuy"><?php echo __('Buy Pro','sassy') ?> </a>
</div>