<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Faded_Small
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function faded_small_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'faded_small_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function faded_small_pingback_header() {
	if ( is_singular() && pings_open() ) {
		echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
	}
}
add_action( 'wp_head', 'faded_small_pingback_header' );

/*  Contact Form 7 Dynamic */

if ( ! function_exists( 'get_contact_form_7_posts' ) ) :
		  function get_contact_form_7_posts(){
		  		  $args = array(
		  		  	'post_type' => 'wpcf7_contact_form',
		  		  	'posts_per_page' => -1
		  		  );
		  		  $catlist=[];
	   
	    if( $categories = get_posts($args)){
	        foreach ( $categories as $category ) {
	                (int)$catlist[$category->ID] = $category->post_title;
	        }
	    }
	    else{
	        (int)$catlist['0'] = esc_html__('No contect From 7 form found', 'sassy');
	    }
 		 return $catlist;
	  }
	
endif;