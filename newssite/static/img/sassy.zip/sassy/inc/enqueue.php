<?php

/* WP Enqueue Style */


add_action('wp_enqueue_scripts', function() {
 wp_enqueue_style('elegant-icon',  SASSY_DIR_ICONS.'/style.css');
 wp_enqueue_style('bootstrap',  SASSY_DIR_CSS.'/bootstrap.min.css');
 wp_enqueue_style('font-awesome',  SASSY_DIR_CSS.'/font-awesome.min.css');
 wp_enqueue_style('magnific-popup',  SASSY_DIR_CSS.'/magnific-popup.css');
 wp_enqueue_style('owl-carousel',  SASSY_DIR_CSS.'/owl.carousel.min.css');
 wp_enqueue_style('scroll-animation',  SASSY_DIR_CSS.'/scroll-animation.css');
 wp_enqueue_style('theme-style',  SASSY_DIR_CSS.'/theme-style.css');
 wp_enqueue_style('style-blog',  SASSY_DIR_CSS.'/blog.css');
});


 add_action('wp_enqueue_scripts', function() {
 wp_enqueue_script('bootstrap-min', SASSY_DIR_JS.'/bootstrap.min.js', array('jquery'), '1.0', true);
 wp_enqueue_script('jquery.waypoints', SASSY_DIR_JS.'/jquery.waypoints.min.js', array('jquery'), '1.0', true);
 wp_enqueue_script('magnific-popup', SASSY_DIR_JS.'/jquery.magnific-popup.min.js', array('jquery'), '1.0', true);
 wp_enqueue_script('owl-carousel', SASSY_DIR_JS.'/owl.carousel.min.js', array('jquery'), '1.0', true);
 wp_enqueue_script('js-plugin', SASSY_DIR_JS.'/plugins.js', array('jquery'), '1.0', true);
 wp_enqueue_script('jquery-mixitup', SASSY_DIR_JS.'/jquery.mixitup.js', array('jquery'), '1.0', true);
 wp_enqueue_script('gmap-js', SASSY_DIR_JS.'/gmap.js', array('jquery'), '1.0', true);
 wp_enqueue_script('parallax-js', SASSY_DIR_JS.'/parallax.js', array('jquery'), '1.0', true);
 wp_enqueue_script('custom-animations', SASSY_DIR_JS.'/custom-animations.js', array('jquery'), '1.0', true);
 wp_enqueue_script('theme', SASSY_DIR_JS.'/theme.js', array('jquery'), '1.0', true);
 
});

  add_action('admin_enqueue_scripts', function() {
    wp_enqueue_style('appi-admin', SASSY_DIR_CSS.'/appi_admin.css');
    wp_enqueue_script('appi_admin_js', SASSY_DIR_JS.'/appi_admin_js.js');
});
